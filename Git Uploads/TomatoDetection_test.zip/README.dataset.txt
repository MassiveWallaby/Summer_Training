# TomatoDetection > 2023-12-17 4:35pm
https://universe.roboflow.com/pranjalproject/tomatodetection-vae6n

Provided by a Roboflow user
License: CC BY 4.0

